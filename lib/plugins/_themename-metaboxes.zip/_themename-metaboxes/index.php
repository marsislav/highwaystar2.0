<?php
/*
Plugin Name:  _themename _pluginname
Plugin URI:
Description:  Adding Metaboxes for _themename
Version:      2.0
Author:       marsislav
Author URI:   https://marsislav.net
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  _themename-_pluginname
Domain Path:  /languages
*/


if( !defined('WPINC')) {
    die;
}

include_once('includes/metaboxes.php');
include_once('includes/enqueue-assets.php');